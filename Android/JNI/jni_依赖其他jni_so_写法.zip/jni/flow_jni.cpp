#include "flow.hpp"

extern "C" void* createFlowSender(const char* name)
{
    return (void*) new flow::Sender(&flow::ctx0, "CorsSender");
}

extern "C" void sendFlowSender(void* sender, const char* topic, const char* data, size_t size)
{
    flow::Sender* senderimpl = (flow::Sender*) sender;
    senderimpl->send(topic, data, size);
    return;
}

extern "C" void destroyFlowSender(void* sender)
{
    flow::Sender* senderimpl = (flow::Sender*) sender;
    delete senderimpl;
}
