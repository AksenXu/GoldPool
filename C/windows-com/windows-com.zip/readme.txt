1 先在设备管理器，查看设备的串口号，例如COM1 COM2... COM100

2 建立文本Lock_sdcard_upgrade_env.txt，将需要串口写下去的内容填入

3 执行 "写环境变量.bat"
    

参考：
1 如何打开COM10以上的串口：https://blog.csdn.net/ninininiwowo/article/details/20380851